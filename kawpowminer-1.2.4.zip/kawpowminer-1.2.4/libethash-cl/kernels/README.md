# ethash-kernels
For whatever reason, Zawawawa released his Ethash kernels as open source code. This repo is a verbaitm copy of that code with a simplistic build environment and [kawpowminer](https://github.com/gangnamtestnet/kawpowminer) as a target. Although the code for kawpowminer has yet to be released.

## Requirements
On Linux, all you need is [clrxasm](https://github.com/CLRX/CLRX-mirror) installed. Everything should build fairly quickly, just make sure to ```mkdir build``` before you ```make```. MacOS should be the same. Windows ¯\_(ツ)_/¯

## Donations
Please buy me alcohol: 
- BTC: 3L2S7FHvTHpjzWqvqgaZBAaqsDzWAgFAdP
- BCH: qq22texutzx4ar4020lmqk0w9vrmvgauc5svtmg6ym
- ETH: 0x9545144F8e473FcD1FF470ab55EF381D4f990C56
- LTC: MWwiHTdKfQDerhQ8a5a4mavGmiAZQYWyB1 

You should also go support Zawawawa, buy him a beer or two for being an awesome chap.
