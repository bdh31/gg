#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

set POOL=eu1.ethermine.org:4444
set WALLET=0x9178e589dD1f057415AC26fCdb5a178b8C078379.l11111olMinerWorker

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./lolMiner --algo ETHASH --pool $POOL --user $WALLET $@
done
